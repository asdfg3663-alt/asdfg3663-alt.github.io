Ares Program | Singularity Soft
App ID: 5440610
Contact: asdfg3663@gmail.com
Website: https://asdfg3663-alt.github.io/
Screenshots are actual development-build gameplay.
Screenshots/PlayerColony shows an actual Sol 28 player save captured on 14 October 2026.
Other screenshots show a prepared gameplay scenario.
Key art is promotional illustration, not gameplay.
Press may use these assets to cover Ares Program; do not imply endorsement.
