Ares Program | Singularity Soft
App ID: 5440610
Contact: asdfg3663@gmail.com
Screenshots are actual development-build gameplay.
Key art is promotional illustration, not gameplay.
Press may use these assets to cover Ares Program; do not imply endorsement.
